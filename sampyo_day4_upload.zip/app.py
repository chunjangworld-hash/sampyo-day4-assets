"""삼표시멘트 설비 고장예측 대시보드 — Streamlit Community Cloud 배포용."""
import pandas as pd
import streamlit as st
import predict as P

st.set_page_config(page_title="설비 고장예측 대시보드", page_icon="⚙️", layout="wide")
meta = P.load_meta()

st.title("⚙️ 설비 고장예측 대시보드")
st.caption(f"우리가 만든 예측 모델 · 정확도 {meta['metrics']['accuracy']:.0%} · "
           f"AUC {meta['metrics']['auc']:.2f}")

with st.sidebar:
    st.header("설비 상태 입력")
    values = {}
    for f in meta["features"]:
        s = meta["slider"][f]
        values[f] = st.slider(meta["labels"][f], float(s["min"]), float(s["max"]),
                              float(s["default"]))

res = P.predict_one(values)
risk_pct = res["risk"] * 100
col1, col2 = st.columns([1, 2])
with col1:
    st.metric("고장 위험도", f"{risk_pct:.0f}%")
    if risk_pct >= 60:
        st.error("🔴 위험 — 점검 권장")
    elif risk_pct >= 30:
        st.warning("🟡 주의 관찰")
    else:
        st.success("🟢 정상 범위")
    st.progress(min(int(risk_pct), 100))
with col2:
    st.subheader("위험을 높인 주요 요인 (간이)")
    for i, fac in enumerate(res["factors"], 1):
        st.write(f"{i}. **{fac['label']}** — 현재값 {values[fac['name']]:.1f} "
                 f"(정상평균 {meta['normal_mean'][fac['name']]:.1f})")

st.divider()
st.subheader("전체 설비 위험 순위 (상위 20)")
df = pd.read_csv(P.HERE / "equipment_data.csv")
ranked = P.score_all(df)[["equipment_id", "risk_pct"]].head(20)
ranked.columns = ["설비ID", "고장위험(%)"]
st.dataframe(ranked, use_container_width=True, hide_index=True)
st.caption("※ 주요 요인은 모델 중요도×정상 대비 편차로 계산한 간이 지표입니다.")
