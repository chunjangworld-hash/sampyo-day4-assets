"""통합 설비 데이터로 고장 분류 모델을 학습하고 model.joblib + meta.json 저장. 1회 실행용."""
import json, joblib, pandas as pd
from pathlib import Path
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, roc_auc_score

HERE = Path(__file__).parent
FEATURES = ['run_hours', 'temp_c', 'vib_mm_s', 'press_bar', 'rpm', 'noise_db',
            'current_a', 'dust_mg', 'oil_visc', 'load_pct']
# 한글 표시명 (UI·요인 설명용)
LABELS = {'run_hours': '가동시간(h)', 'temp_c': '온도(℃)', 'vib_mm_s': '진동(mm/s)',
          'press_bar': '압력(bar)', 'rpm': '회전수(rpm)', 'noise_db': '소음(dB)',
          'current_a': '전류(A)', 'dust_mg': '분진농도(mg)', 'oil_visc': '윤활유 점도',
          'load_pct': '부하율(%)'}


def main():
    df = pd.read_csv(HERE / "equipment_data.csv")
    X, y = df[FEATURES], df['failure']
    Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.25,
                                          random_state=42, stratify=y)
    model = GradientBoostingClassifier(random_state=42)
    model.fit(Xtr, ytr)
    proba = model.predict_proba(Xte)[:, 1]
    acc = accuracy_score(yte, model.predict(Xte))
    auc = roc_auc_score(yte, proba)

    normal = df[df['failure'] == 0][FEATURES]
    meta = {
        "features": FEATURES,
        "labels": LABELS,
        "importances": dict(zip(FEATURES, model.feature_importances_.round(4).tolist())),
        "normal_mean": normal.mean().round(3).to_dict(),
        "normal_std": normal.std().round(3).replace(0, 1e-6).to_dict(),
        "slider": {f: {"min": float(df[f].quantile(0.01).round(2)),
                       "max": float(df[f].quantile(0.99).round(2)),
                       "default": float(df[f].median().round(2))} for f in FEATURES},
        "metrics": {"accuracy": round(float(acc), 3), "auc": round(float(auc), 3)},
    }
    joblib.dump(model, HERE / "model.joblib")
    (HERE / "meta.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2),
                                    encoding="utf-8")
    print(f"saved. acc={acc:.3f} auc={auc:.3f}")


if __name__ == "__main__":
    main()
