"""고장예측 순수 로직 — Streamlit UI와 분리(단위테스트 가능)."""
import json, joblib, pandas as pd
from pathlib import Path

HERE = Path(__file__).parent
_model = None
_meta = None


def load_meta():
    global _meta
    if _meta is None:
        _meta = json.loads((HERE / "meta.json").read_text(encoding="utf-8"))
    return _meta


def load_model():
    global _model
    if _model is None:
        _model = joblib.load(HERE / "model.joblib")
    return _model


def predict_one(values: dict) -> dict:
    """values: {feature: number}. 반환 {risk: 0~1, factors: 상위3 [{name,label,contribution}]}"""
    meta = load_meta()
    feats = meta["features"]
    row = pd.DataFrame([[float(values[f]) for f in feats]], columns=feats)
    risk = float(load_model().predict_proba(row)[0, 1])
    # 간이 영향도: 중요도 × 정상평균 대비 양의 표준화 편차
    factors = []
    for f in feats:
        dev = (float(values[f]) - meta["normal_mean"][f]) / meta["normal_std"][f]
        contrib = meta["importances"][f] * max(dev, 0.0)
        factors.append({"name": f, "label": meta["labels"][f],
                        "contribution": round(contrib, 4)})
    factors.sort(key=lambda d: d["contribution"], reverse=True)
    return {"risk": risk, "factors": factors[:3]}


def score_all(df: pd.DataFrame) -> pd.DataFrame:
    meta = load_meta()
    feats = meta["features"]
    proba = load_model().predict_proba(df[feats])[:, 1]
    out = df.copy()
    out["risk_pct"] = (proba * 100).round(1)
    return out.sort_values("risk_pct", ascending=False).reset_index(drop=True)
